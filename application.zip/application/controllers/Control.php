<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Control extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function __construct(){
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('array');
		$this->load->helper('url');
		$this->load->library('form_validation');
		$this->load->library('session');					
		$this->load->model('Class_model','model');

	}
	public function index()
	{
			$this->load->view('index.php');	
			
	
	}
	public function redcadastro(){
		if (isset($_POST['nome']) && isset($_POST['sobrenome']) && isset($_POST['email']) && isset($_POST['senha'])){
				$obj = array(
					'nome' => $_POST['nome'],
					'sobrenome'  => $_POST['sobrenome'],				
					'email'  => $_POST['email'],			
					'senha'  => md5($_POST['senha'])
					
				);	
				session_destroy();									
				$data = $this->model->inserirUser($obj);
				if($data === "Este email já foi registrado!" ){
					$this->session->set_flashdata("warning",$data);
					$dado['formindex'] = 'cadastro';
					
					$this->load->view('index',$dado);
				}
				else {
					$dado['formindex'] = 'cadastro';					
					$this->session->set_flashdata("success",$data);
					$this->load->view('index',$dado);	
				}
		}
		else{
			$this->load->view('cadastro');	
			
		}	
	}
	public function formcad(){
		$form['formindex'] = 'cadastro';					
		$this->load->view('index',$form);	
		
	}		
	public function logar(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$email = $_POST['email'];
			$senha = md5($_POST['senha']);
			$data = $this->model->verificarUser($email,$senha);
			if($data){
				$_SESSION['nome'] = $data['nome'];
				$_SESSION['sobrenome'] = $data['sobrenome'];				
				$_SESSION['id'] = $data['id'];
				$_SESSION['email'] = $data['email'];
				$this->session->set_userdata('usuario', $data);
				header('Location:inicial');
			}
			else{
				$this->session->set_flashdata("error",'Usuário ou Senha incorretos');
				$this->load->view('login');	
			} 
		}
		else{
			$this->load->view('login');	
			
		}
	}
	public function feedUser(){
		$dado['feed']=$this->model->feedUser($_SESSION['id'])->result();
		$dado['meuscursos'] = $this->model->meuscursos()->result();
		$dado['gxcursos'] = $this->model->listcursos()->result();
		return print_r($dado['feed']);
		$this->load->view('inicial',$data);
		
	}
	public function sobre(){
		$this->load->view('sobre');
		
	}		
	public function ebook(){
		$this->load->view('ebook');
		
	}		
	public function cursosgx(){
		$dado['gxcursos'] = $this->model->listcursos()->result();		
		$this->load->view('cursosgx',$dado);
		
	}	

	public function cursos(){
		$dado['gxcursos'] = $this->model->listcursos()->result();		
		$this->load->view('cursos',$dado);
		
		
	}
	
	public function todosvideos(){
		$dado['gxcursos'] = $this->model->listcursos()->result();
		$dado['videos'] = $this->model->listvideos()->result();		
		
		$this->load->view('todosvideos',$dado);
		
	}

	public function alterarComentarioVideo(){
		echo $_POST['id_video'];
		$obj = array(
			'id' => $_POST['id_comentario'],
			'texto'  => $_POST['comentario']		
		);				
		$this->model->alterarComentarioVideo($obj);
		header('Location:proximoVideo?id='.$_POST['id_video'].'');
		
	}	

	public function alterarPublicacao(){
		$id = $_POST['id'];	
		$msg = $_POST['msg'];			
		$obj = array(
			'id' => $id,
			'mensagem'  => $msg			
		);				
		$this->model->alterarPublicacao($obj);
		header('Location:inicial');
		
	}		
	public function alterarComentario(){
		$obj = array(
			'id' => $_POST['id_comentario'],
			'mensagem'  => $_POST['comentario']		
		);				
		$this->model->alterarComentario($obj);
		header('Location:inicial');
		
	}		
	
	public function deletarComentario(){
		$this->model->deletarComentario($_GET['id']);	
		header('Location:inicial');
		
	}
	public function deletarComentarioVideo(){
		$this->model->deletarComentarioVideo($_GET['id']);	
		header('Location:videoaulas');		
		header('Location:proximoVideo?id='.$_GET['id_video'].'');

		
	}
	public function comentarVideo(){
		date_default_timezone_set('America/Sao_Paulo');
		// CRIA UMA VARIAVEL E ARMAZENA A HORA ATUAL DO FUSO-HORÀRIO DEFINIDO (BRASÍLIA)
		$data = date('Y-m-d H:i:s', time());
		$id = $_POST['id_video'];
		$obj = array(
			'data' => $data,
			'texto'  => $_POST['comentario'],
			'id_usuario'  => $_SESSION['id'],			
			'id_video'  => $id			
			
		);	
		$this->model->comentarVideo($obj);
	    header('Location:proximoVideo?id='.$id.'');

	}
		
	
		
	public function comentar(){
		date_default_timezone_set('America/Sao_Paulo');
		// CRIA UMA VARIAVEL E ARMAZENA A HORA ATUAL DO FUSO-HORÀRIO DEFINIDO (BRASÍLIA)
		$data = date('Y-m-d H:i:s', time());
		$obj = array(
			'data' => $data,
			'mensagem'  => $_POST['comentario'],
			'id_user'  => $_SESSION['id'],			
			'id_publicacao'  => $_POST['id_publicacao']			
			
		);	
		$this->model->comentar($obj);	
		header('Location:inicial');
		
	}
		
	public function alterarVideo(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$id = $_POST['id'];						
			$obj = array(
				'ep'  => $_POST['ep'],
				'titulo'  => $_POST['titulo'],
				'id_curso'  => $_POST['id_curso']				
					
			);				
			$data = $this->model->alterarVideo($id,$obj);		
			header("Location:todosvideos");
		}
		else{
			$id = $_GET['id'];
			$data['video'] = $this->model->buscarVideo($id);	
			$data['cursos'] = $this->model->listcursos()->result();
			$this->load->view('alterarVideo',$data);
			
		}
		
	}
	public function excluirVideo(){
		$id = $_GET['id'];
		$this->model->excluirVideo($id);		
		header("Location:todosvideos");
		
	}
	public function meucurso(){
		$cod_curso = $_GET['id_curso'];
		$ep_video = $_GET['ep_video'];
		$dado['curso'] = $this->model->cursoatual($cod_curso)->result();		
		$dado['videos'] = $this->model->cursoatualvideos($cod_curso,$ep_video,$_SESSION['id'])->result();		
		$dado['videomenos1'] = $this->model->videomenos($cod_curso,$ep_video,$_SESSION['id'])->result();		
		$this->load->view('meucurso',$dado);
	}	
	public function curso(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){			
			$id = $_POST['cursoid'];
			$dado['curso'] = $this->model->cursoatual($id)->result();		
			$this->load->view('curso',$dado);
		}
		else{
			$id = $_GET['id'];
			$dado['curso'] = $this->model->cursoatual($id)->result();		
			$this->load->view('curso',$dado);			
		}
		
	}
	public function minhaconta(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){			
			
			$obj = array(
				'nome' => $_POST['nome'],
				'sobrenome'  => $_POST['sobrenome'],				
				'email'  => $_POST['email'],
				'numero'  => $_POST['tel'],							
				'senha'  => md5($_POST['senha'])
				
			);	
			$dado['user'] = $this->model->alterarConta($_SESSION['id'],$obj);				
			header("Location:inicial");			
			
		}
		else{
			$dado['user'] = $this->model->buscarUser($_SESSION['id'])->result();				
			$this->load->view('minhaconta',$dado);
		}
			
		
	}	
	public function sair(){
		session_destroy();
		header("Location:index");					
    }
	public function assistir(){
		$cod_video = $_GET['id_video'];
		$cod_curso = $_GET['id_curso'];
		$dado['videoAtual']=$this->model->videoatual($cod_video)->result();
		$dado['videomenos1']=$this->model->videomenos1($cod_video,$cod_curso,$_SESSION['id'])->result();
		$this->load->view('assistir',$dado);
		
	}	
	public function deletarCurso(){
		$cod_curso = $_GET['id'];
		$this->model->deletarCurso($cod_curso);
		header('Location:todosvideos');
	}
	public function assistirNovoEp(){
		$dado['videoAtual']=$this->model->videoatual($_GET['id_video'])->result();
		$dado['videomenos1']=$this->model->listadevideosmenos1($_GET['id_video'],$_GET['ep'],$_GET['cod_curso'],$_SESSION['id'])->result();
		$this->load->view('assistir',$dado);
		
	}
	public function alterarCurso(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$preco = $_POST['preco'];
			$id_curso = $_POST['id_curso'];
			$preco = str_replace(",", ".", $preco);
			$obj = array(
				'titulo' => $_POST['titulo'],
				'preco'  =>  $_POST['preco'],				
				'info'  => $_POST['info']	
					
			);	
							
			$id_user = $this->model->insertCurso($obj);
			$data['userAntigo'] = $this->model->UsersDoCursoAtual($id_curso)->result();	
			foreach ($data['userAntigo'] as $cli) {
				$obj = array(
					'id_user' =>$cli->id,
					'id_curso'  => $id_curso				
				);	
				$data = $this->model->deletarCursoCli($obj);
			}	
			foreach ($_POST['clientes'] as $cli) {
				$obj = array(
					'id_user' =>$cli,
					'id_curso'  => $id_curso				
				);	
				$data = $this->model->insertCursoCli($obj);
				header('Location:todosvideos');
			} 
	    }
		else{
			$data['userAntigo'] = $this->model->UsersDoCursoAtual($_GET['cod'])->result();						
			$data['users'] = $this->model->listusers()->result();			
			$data['curso'] = $this->model->cursoatual($_GET['cod'])->result();					
			$this->load->view('alterarCurso',$data);	
		} 

	}
	public function cadastrarcurso(){
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			$titulo = $_POST['titulo'];
			$preco = $_POST['preco'];
			
			$preco = str_replace(",", ".", $preco);
   			$obj = array(
				'titulo' => $_POST['titulo'],
				'preco'  =>  $_POST['preco'],				
				'info'  => $_POST['info']	
					
			);	
							
			$id_curso = $this->model->insertCurso($obj);
			foreach ($_POST['clientes'] as $cli) {
				$obj = array(
					'id_user' =>$cli,
					'id_curso'  => $id_curso			
				);	
				$data = $this->model->insertCursoCli($obj);
				header('Location:cursosgx');
			}
	    }
		else{
			$data['users'] = $this->model->listusers()->result();			
			$this->load->view('cadastrocurso',$data);	
		} 

	}
	public function alterarFoto(){
		print_r($_FILES);
		$nome=$_FILES['foto']['tmp_name'];
		$name=$_FILES['foto']['name'];			
		$ext = pathinfo($name, PATHINFO_EXTENSION);
		$nome_foto = md5(uniqid(time())).".".$ext;
		$dir =$_SERVER['DOCUMENT_ROOT'].'/perfil/'.$nome_foto;	
		move_uploaded_file($_FILES['foto']['tmp_name'], $dir);						
		chmod($dir, 0664);			
		$obj = array(			
			'foto'  => $nome_foto	
			
		);
	    $dado['publicao'] = $this->model->alterarConta($_SESSION['id'],$obj);
		header("Location:inicial");
         		
	}	
	public function publicar(){
		$obj = array(			
			'id_user'  => $_POST['id_user'],
			'data'  => $_POST['data'],	
			'mensagem'  => $_POST['publicacao']	
			
		);
		$this->model->insertPublicacao($obj);
		header("Location:inicial");
         		
	}	
	public function proximoVideo()
	{
		$vetor = [['<iframe width="115%" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/0CC_m-83-gA?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 1 - O que é renda passiva?','O que é uma renda passiva? Como investir para alcançar uma renda que sustente o
		seu padrão de vida? Esses são os temas da primeira parte das aulas introdutórias
		dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/0CC_m-83-gA/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/lKof9ZLjEWg?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 2 - Como funcionam as ações?','Afinal de contas, o que é uma ação? Qual a minha participação na empresa depois
		de comprar esse tipo de produto? Quais são os tipos disponíveis no mercado?
		Esses são os temas da segunda parte das aulas introdutórias dentro do curso:
		Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/lKof9ZLjEWg/sddefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/PW3QVFoCdOc?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 3 - O que significa volatilidade?','Qual a relação entre risco e rentabilidade? Quais tipos de investimentos têm mais a ver com o meu perfil? Esses são os temas da terceira parte das aulas introdutórias
		dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/PW3QVFoCdOc/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/QzFvm-Rtu3A?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 4 - O que é um balanço patrimonial?
			','Como funciona o balanço patrimonial? O que são ativos e passivos, circulantes e
		não-circulantes, patrimônio líquido...? Acompanhe a penúltima parte das aulas
		introdutórias dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/QzFvm-Rtu3A/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/9EOqQvUJvP4?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 5 - Como usar um book de ofertas?','Quais as vantagens de utilizar um book de ofertas? Como obter as informações
		mais importantes? Vamos te apresentar a ferramenta na última parte das aulas
		introdutórias dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/9EOqQvUJvP4/maxresdefault.jpg'],['<iframe width="115%" height="537" src="https://www.youtube.com/embed/xXQyPaYFdko?list=UUS-66akDVGt3vgSvG_ppweg"
		style="position:relative;left:-2.5%;"
		frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','Alcance sua LIBERDADE FINANCEIRA!','O que é a liberdade financeira? Como calcular o índice? Como fazer para se tornar livre financeiramente? Nosso sócio-diretor, Vinícius Teixeira, explica tudo sobre o assunto e ensina a utilizar a planilha completa que criamos.','https://i.ytimg.com/vi/xXQyPaYFdko/maxresdefault.jpg']];
		$id=$_GET['id'];
		$vetor2 = [];
		for ($i=0; $i < count($vetor); $i++) { 
			array_push($vetor2,['id'=>$i+1,'nome'=>$vetor[$i][0],'titulo'=>$vetor[$i][1],'descricao'=>$vetor[$i][2],'imagem'=>$vetor[$i][3]]);
		}
		$atual = $vetor2[$id-1];
		unset($vetor2[$id-1]);
		$data['videoAtual']=$atual;	
		$data['videos']=$vetor2;
		$data['comentarios'] = $this->model->listcomment($atual['id']);
		$this->load->view('jornada',$data);	
	}
	public function videoaulas(){
		$vetor = [['<iframe width="115%" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/0CC_m-83-gA?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 1 - O que é renda passiva?','O que é uma renda passiva? Como investir para alcançar uma renda que sustente o
		seu padrão de vida? Esses são os temas da primeira parte das aulas introdutórias
		dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/0CC_m-83-gA/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/lKof9ZLjEWg?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 2 - Como funcionam as ações?','Afinal de contas, o que é uma ação? Qual a minha participação na empresa depois
		de comprar esse tipo de produto? Quais são os tipos disponíveis no mercado?
		Esses são os temas da segunda parte das aulas introdutórias dentro do curso:
		Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/lKof9ZLjEWg/sddefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/PW3QVFoCdOc?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 3 - O que significa volatilidade?','Qual a relação entre risco e rentabilidade? Quais tipos de investimentos têm mais a ver com o meu perfil? Esses são os temas da terceira parte das aulas introdutórias
		dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/PW3QVFoCdOc/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/QzFvm-Rtu3A?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 4 - O que é um balanço patrimonial?
			','Como funciona o balanço patrimonial? O que são ativos e passivos, circulantes e
		não-circulantes, patrimônio líquido...? Acompanhe a penúltima parte das aulas
		introdutórias dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/QzFvm-Rtu3A/maxresdefault.jpg'],['<iframe width="115%	" style="position:relative;left:-2.5%;" height="537" src="https://www.youtube.com/embed/9EOqQvUJvP4?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','AULA 5 - Como usar um book de ofertas?','Quais as vantagens de utilizar um book de ofertas? Como obter as informações
		mais importantes? Vamos te apresentar a ferramenta na última parte das aulas
		introdutórias dentro do curso: Aprenda a Investir na Bolsa.','https://i.ytimg.com/vi/9EOqQvUJvP4/maxresdefault.jpg'],['<iframe width="1446" height="753" src="https://www.youtube.com/embed/xXQyPaYFdko?list=UUS-66akDVGt3vgSvG_ppweg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>','Alcance sua LIBERDADE FINANCEIRA!','O que é a liberdade financeira? Como calcular o índice? Como fazer para se tornar livre financeiramente? Nosso sócio-diretor, Vinícius Teixeira, explica tudo sobre o assunto e ensina a utilizar a planilha completa que criamos.','https://i.ytimg.com/vi/xXQyPaYFdko/maxresdefault.jpg']];
		$vetor2 = [];
		for ($i=0; $i < count($vetor); $i++) { 
			array_push($vetor2,['id'=>$i+1,'nome'=>$vetor[$i][0],'titulo'=>$vetor[$i][1],'descricao'=>$vetor[$i][2],'imagem'=>$vetor[$i][3]]);
		}
		$data['videoAtual']=$vetor2[0];	
		unset($vetor2[0]);	
		$data['videos']=$vetor2;
		$id=1;
		$data['comentarios'] = $this->model->listcomment($id);
	
		$this->load->view('jornada',$data);	
		
         		
	}	
	public function inicial(){
		$obj = array(			
			'email'  => $_SESSION['email'],
			'id'  => $_SESSION['id'],	
			'nome'  => $_SESSION['nome']	
			
			
		);
		$data['listpublic'] = $this->model->listpublic()->result();
		foreach ($data['listpublic'] as $public) {
			$cod_public = $public->id;
		}			
		$data['listcomentarios'] = $this->model->listcomentarios()->result();		
		$data['meuscursos'] = $this->model->meuscursos($obj)->result();
		$data['gxcursos'] = $this->model->listcursos()->result();
		$data['perfil']=$this->model->perfilUser($_SESSION['id'])->result();	
		$data['feed']=$this->model->feedUser($_SESSION['id'])->result();
		$this->load->view('inicial',$data);
		
	}	
	public function deletarPublic (){
		$id = $_GET['id'];
		$this->model->deletarPublic($id);
		header("Location:inicial");
	}
	public function uparvideo(){	
		if ($_SERVER['REQUEST_METHOD'] == "POST"){
			//echo "caralho\n";
			$nome=$_FILES['nome']['tmp_name'];
			$name=$_FILES['nome']['name'];			
			$ext = pathinfo($name, PATHINFO_EXTENSION);
			$nome_video = md5(uniqid(time())).".".$ext;
			$dir =$_SERVER['DOCUMENT_ROOT'].'/videos/'.$nome_video;	
			move_uploaded_file($_FILES['nome']['tmp_name'], $dir);						
			chmod($dir, 0664);			
			
   			$obj = array(
				'nome'  =>  $nome_video,				
				'ep'  => $_POST['ep'],
				'titulo'  => $_POST['titulo'],
				'id_curso'  => $_POST['id_curso']				
					
			);				
			$data = $this->model->insertVideo($obj);
			echo "vídeo inserido com sucesso";
		}
		else{
			$data['cursos'] = $this->model->listcursos()->result();				
			$this->load->view('uparvideo',$data);
		}						
	}	
	

}

