<?php

class Class_model extends CI_Model{


    public function inserirUser($obj){
        $email = $obj['email'];
        $query = $this->db->query("SELECT * FROM usuario WHERE email='".$email."'");
        if ($query->result() != NULL){
            return "Este email já foi registrado!";            
        }      
        else {
            $this->db->insert('usuario',$obj);   
            return "Cadastro realizado com sucesso!";            
        }

    }
    public function comentar($obj){     
        $this->db->insert('comentario',$obj);   
        return "enviado";
    }
    public function comentarVideo($obj){     
        $this->db->insert('comentarioVideo',$obj);   
        return "enviado";
    }
    public function proximoVideo($obj){     
        $this->db->insert('comentario',$obj);   
        return "enviado";
    }
    public function listpublic(){     
        $query = $this->db->query("SELECT p.id,p.data,u.foto,p.id_user,u.nome,u.sobrenome,p.mensagem FROM publicacao p INNER JOIN usuario u on u.id = p.id_user ORDER BY p.data DESC ");
        return $query;
    }
    public function alterarPublicacao($obj){ 
        $this->db->where('id', $obj['id']);        
        $this->db->set($obj);        
        $this->db->update('publicacao',$obj);  
    }
    public function alterarComentarioVideo($obj){ 
        $this->db->where('id', $obj['id']);        
        $this->db->set($obj);        
        $this->db->update('comentarioVideo',$obj);  
    }
    public function alterarComentario($obj){ 
        $this->db->where('id', $obj['id']);        
        $this->db->set($obj);        
        $this->db->update('comentario',$obj);  
    }
    public function deletarComentarioVideo($id){
        $this->db->where('id', $id);
        $this->db->delete('comentarioVideo');  
    }
    public function deletarComentario($id){
        $this->db->where('id', $id);
        $this->db->delete('comentario');  
    }
    public function listcomentarios(){     
        $query = $this->db->query("SELECT c.id as id_comentario,u.foto,c.id_user, c.mensagem as comentario,id_publicacao,u.nome,u.sobrenome, c.data as data_comentario FROM `comentario` as c INNER JOIN   `publicacao` p ON c.id_publicacao = p.id INNER JOIN usuario u on c.id_user = u.id");
        return $query; 
    }
    public function listcomment($id){     
        $query = $this->db->query("SELECT v.id as id_video,c.id as id_comentario,data,u.foto,c.id_usuario as id_user, c.texto as comentario,u.nome,u.sobrenome, c.data as data_comentario FROM `video` as v INNER JOIN   `comentarioVideo` c ON c.id_video = v.id INNER JOIN usuario u on c.id_usuario = u.id WHERE v.id='".$id."'");
        if ($query->result() == NULL){
            $query = "Nenhum comentário";
            return $query;
        }
        return $query->result(); 
    }
    public function deletarPublic($id) {
        $this->db->where('id', $id);
        $this->db->delete('publicacao');        
    }
    public function insertPublicacao($obj){     
        $this->db->insert('publicacao',$obj);   
        return "enviado";
    }
    public function verificarUser($email,$senha){     
        $query = $this->db->get_where('usuario', array('email'=>$email,'senha'=>$senha));
        return $query->row_array();
    }
    public function insertCurso($obj){     
        $titulo = $obj['titulo'];
        $query = $this->db->query("SELECT * FROM curso WHERE titulo='".$titulo."'");
        if ($query->result() != NULL){
            return "Esse curso já existe!";            
        }      
        else {
            $query = $this->db->insert('curso',$obj);   
            $insert_id = $this->db->insert_id();
            return  $insert_id;
        }

    }
    public function insertCursoCli($obj){     
        $this->db->insert('usercurso',$obj);   
        $insert_id = $this->db->insert_id();
        return  $insert_id;
    }
    public function insertVideo($obj){     
        $this->db->insert('video',$obj);   
    }
    
    public function alterarVideo($id,$obj){     
        $this->db->where('id',$id);
        $query = $this->db->update("video",$obj);
        
    }
    public function alterarCurso($id,$obj){     
        $this->db->where('id',$id);
        $query = $this->db->update("curso",$obj);
        
    }
    public function alterarConta($id,$obj){     
        $this->db->where('id',$id);
        $query = $this->db->update("usuario",$obj);
        
    }  

    public function perfilUser($id){     
        return  $this->db->query("SELECT foto FROM usuario WHERE id='".$id."'");
        
    }  
    public function videoatualpelonome($nome,$ep){     
        $query = $this->db->query("SELECT v.nome,v.titulo,c.titulo as curso,c.id as cursoid,v.id,v.descricao FROM video v INNER JOIN curso c on v.id_curso = c.id WHERE v.nome='".$nome."' AND v.ep='".$ep."'");
        return $query;
        
    }
    public function listadevideosmenos1($id_video,$ep,$cod_curso,$cod_user){ 
 
        $query = $this->db->query("SELECT v.nome,v.descricao,v.titulo,v.ep,v.id,c.id as cod_curso FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso INNER JOIN video v on v.id_curso = c.id  WHERE  v.id!='".$id_video."' AND c.id='".$cod_curso."' AND u.id='".$cod_user."' ORDER BY v.ep desc ");
        return $query;
        
    }
    public function deletarCursoCli($obj){     
        $query = $this->db->query("DELETE FROM usercurso WHERE id_curso='{$obj['id_curso']}' AND id_user='{$obj['id_user']}' ");
        return $obj['id_curso'];
        
    }
    public function meuscursos($obj){
        $query = $this->db->query("SELECT c.titulo,c.id  FROM usuario u RIGHT JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id = uc.id_curso WHERE u.email='{$obj['email']}'");
        return $query;
    }
    public function videoatual($id){
        $query = $this->db->query("SELECT v.nome,v.titulo,c.titulo as curso,c.id as cursoid,v.id,v.descricao FROM video v INNER JOIN curso c on v.id_curso = c.id WHERE v.id='".$id."'");
        return $query;
    }
    public function cursoatual($id){
        $query = $this->db->query("SELECT * FROM curso  WHERE id='".$id."'");
        return $query;
    }
    public function buscarUser($id){
        $query = $this->db->query("SELECT * FROM usuario  WHERE id='".$id."'");
        return $query;
    }
    public function videomenos1($cod_video,$cod_curso,$cod_user){
        $query = $this->db->query("SELECT v.nome,v.descricao,v.titulo,v.id,v.ep,c.id as cod_curso FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso INNER JOIN video v on v.id_curso = c.id  WHERE  v.id!='".$cod_video."' and c.id='".$cod_curso."' AND u.id='".$cod_user."'");
        return $query;
    }
    public function videomenos($cod_curso,$ep_video,$cod_user){
        $query = $this->db->query("SELECT v.nome,v.descricao,v.titulo,v.ep,v.id,c.id as cursoid, c.titulo as curso FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso INNER JOIN video v on v.id_curso = c.id  WHERE  c.id='".$cod_curso."' AND v.ep !='".$ep_video."' AND u.id='".$cod_user."'");
        return $query;
    }
    public function cursoatualvideos($cod_curso,$ep_video,$cod_user){
        $query = $this->db->query("SELECT v.nome,v.descricao,v.titulo,v.id,c.id as cursoid, c.titulo as curso FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso INNER JOIN video v on v.id_curso = c.id  WHERE  c.id='".$cod_curso."' AND v.ep ='".$ep_video."' AND u.id='".$cod_user."'");
        return $query;
    }
    public function feedUser($id){
        $query = $this->db->query("SELECT v.nome,v.descricao,v.titulo,v.id,c.titulo as curso,c.id as cursoid FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso INNER JOIN video v on v.id_curso = c.id  WHERE u.id='".$id."'");
        return $query;
    }
    public function UsersDoCursoAtual($id){
        $query = $this->db->query("SELECT u.id FROM usuario u INNER JOIN usercurso uc on uc.id_user= u.id INNER JOIN curso c on c.id= uc.id_curso WHERE uc.id_curso='".$id."'");
        return $query;
    }
    public function listcursos(){
        $query = $this->db->query("SELECT * FROM curso ");
        return $query;
    }
    public function listusers(){
        $query = $this->db->query("SELECT * FROM usuario ");
        return $query;
    }
    public function listvideos(){
        $query = $this->db->query("SELECT * FROM video ");
        return $query;
    }

    public function buscarVideo($id){
        $query = $this->db->query("SELECT * FROM video where id ='".$id."'");
        return $query->result();
    }
    public function excluirVideo($id){
        $query = $this->db->query("DELETE  FROM video WHERE id ='".$id."'");
        return $query;
    }
    public function deletarCurso($cod){
        $table = array('curso');
        $this->db->where('id',$cod);
        $this->db->delete($table);
    }     
}

?>
