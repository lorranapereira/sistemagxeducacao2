<?php
require_once("layout/navbar.php");

?>
  
<!-- Side Widget -->
    <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
      <div class="card card-signin my-5">
        <div class="card-body">
          <h5 class="card-title text-center">Inserir vídeo</h5>
            <?php
                if ($this->session->flashdata('error')) {
                ?>
                    <div class="alert alert-danger text-center" style="margin-top:20px;">
                        <?php echo $this->session->flashdata('error'); ?>
                    </div>
                    <?php
                }
            ?> 
          <form class="form-signin" action="alterarVideo" enctype="multipart/form-data" method="POST">
            <?php foreach ($video as $v): ?>      
             <div class="form-label-group">
                <label for="inputEmail">Nome do Vídeo</label>                        
                <input type="text" name="titulo" class="form-control" value="<? echo $v->titulo; ?>" placeholder="Nome do Vídeo" required autofocus>
              </div>
              <br/>
              <input type="text" style="display:none;" name="id" value="<? echo $v->id; ?>" >

              <div class="form-label-group">
                <label for="inputPassword">Episódio</label>                        
                <input type="number" id="inputPassword" name="ep" value="<? echo $v->ep; ?>" class="form-control" step="0.01" placeholder="Episódio" required>
              </div>
              <br/>
              <div class="form-label-group">
                <label for="inputPassword">Curso</label><br/>  
                <select class="form-control" name="id_curso" id="">
                <?php foreach ($cursos as $row): ?>      
                    <option value="<? echo $row->id; ?>" <? if($row->id == $v->id_curso){ echo "selected";}?>><? echo $row->titulo; ?></option>
                  </li>
                <?php endforeach ?>
                </select>                    
              </div>
              <br/>
              <br/>
              <button type="submit" id="enviar" class="btn btn-success btn-lg">Enviar</button>
              <hr class="my-4">
              <?php endforeach ?>

          </form>

        </div>
      </div>
    </div>
  </div>
  </div>
  <script>

    var input = document.getElementById('input-file');
    var fileName = document.getElementById('file-name');
    input.addEventListener('change', function(evt){
   //document.getElementById('enviar').style.display = "none";
          
      file = evt.target.files[0];
      fileName.textContent = file.name;

  
    });
  </script>
  

    <!-- /.row -->

  <!-- /.container -->
<?php
  require_once("layout/footer.php");  
?>