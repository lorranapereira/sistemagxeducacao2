<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<html lang="en">
<!-- https://www.mercadopago.com.br/checkout/v1/redirect/3cf05c38-846a-4f27-b6c2-8653ecce2f5a/review/?preference-id=141311553-82bd9a80-c430-4953-9f67-f941fb12a642 !-->
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link href="/css2/style.css" rel="stylesheet">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
  <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>

  <link href="https://fonts.googleapis.com/css?family=Playfair+Display&display=swap" rel="stylesheet">
  <title>Gx Educação</title>
  <link href="https://fonts.googleapis.com/css?family=Abril+Fatface|Rubik:500&display=swap" rel="stylesheet">
<!-- Bootstrap core CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick.css">
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.9.0/slick-theme.css">
  <link rel="stylesheet" href="/css/login.css" >
  <link rel="stylesheet" href="/css/indexstyle.css" >
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Heebo&display=swap" rel="stylesheet"> 
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Heebo|Jomolhari|Playfair+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 <!-- <link href="css/modern-business.css" rel="stylesheet"> -->
  <style>
    p{
      color:black!important;
      font-family: "Times New Roman", Times, serif;

    }
    .ponto li {
      list-style: initial!important;
    }
  </style>
</head>

<body id="body" style="background-color: #e0dfef;" >
<?php
    require_once("layout/navindex.php");  
?>
<img style="position:absolute;index-z:-1;top:0;margin:0;height:40%;width:100%;" src="/css/jornada.jpg" alt="">
<!-- Page Content-->

<div class="container"> 

  <br/>
  <br/>
  <br/>


<h1 class="mt-4 mb-3" style="position:relative;color:white;top:1em; text-align:center; font-family: Raleway, sans-serif;border-bottom: 2px solid white; ">
JORNADA DO INVESTIDOR
  </h1>
  </br>
<div  style="opacity: 1.0; border-radius:2%;" class="container">

  <!-- Page Heading/Breadcrumbs -->
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>
  <br/>

  <?php foreach ($gxcursos as $row): ?> 
  <br/>
  <div class="row">

    <!-- Post Content Column -->
    <div class="col-lg-8"  style="color:black!important;font-family: Raleway, sans-serif;">
      <!-- Preview Image -->
      <img class="img-fluid rounded" src="/css/fundocad.png" alt="">


      <hr>

      <!-- Post Content -->
      <p class="lead"><? echo $row->info; ?></p>
      <hr>

      <p> <strong style="color:black!important;" >OBJETIVOS: </strong></p>
      <ul class="ponto">
        <li> Desenvolver uma compreensão a respeito;</li>
        <li> Fornecer instrumental analítico em gráficos;</li>
        <li> Estimular a reflexão sobre problemas e dilemas relacionados ao investimentos.</li>
      </ul>
      <hr>
        <p> <strong> RECURSOS UTILIZADOS  </strong></p>

            <ul class="ponto">
                <li>
                   Videoaula 
                </li>
                <li>
                   Computador 
                </li>
                <li>
                   Apostila 
                </li>
              </ul>

      <hr>
      <p> <strong>ANÁLISE TÉCNICA</strong> </p>
      <p>A análise técnica procura determinar o melhor
          momento para a compra e a venda de ativos.
          Seu principal objetivo é mensurar o comportamento
          dos preços através da utilização de gráficos
          como principal ferramenta, aliados a fórmulas
          matemáticas e cálculos estatísticos. Dessa forma,
          permite ao investidor maximizar seus lucros e
          minimizar os riscos, por meio de previsões de preços
          futuros das ações, pois está baseada no fato
          de que todos os fatores podem influir no preço
          de um determinado ativo.</p>
      <p>A análise técnica é muito usada em operações
          em que o investidor visa obter ganhos em curto
          espaço de tempo (day trade), onde os gráficos
          também podem ser usados para operações mais
          longas na Bolsa, bastando calibrar seus indicadores. </p>
      <p>Com algumas técnicas simples
            de gerenciamento de risco, você poderá limitar
            o tamanho da perda e prolongar os ganhos
            o máximo possível. Independentemente
            da estratégia a ser adotada para lucratividade em
            seus investimentos, a análise técnica é fundamental
            para a formação de investidores mais conscientes de
            suas possibilidades, mais seguros de suas ações e
            sensatos em suas operações.</p>
      <br/>
      <br/>
      </div>
      <hr>

    <!-- Sidebar Widgets Column -->
    <div class="col-md-4">

      <!-- Search Widget -->
      <div class="card mb-4">
        <h2 class="card-header">Garanta sua vaga!</h2>
        <div class="card-body">
          <div class="input-group">
            <span class="input-group-btn">
              <button class="btn btn-primary" id="logar" type="button">Comprar!
                <i class="fa fa-shopping-cart" style="font-size:20px;color:red"></i>
              </button>
            </span>
          </div>
        </div>
      </div>
      <!-- Categories Widget -->
      <div class="card my-4">
        <h4 class="card-header">METODOLOGIA</h4>
        <div class="card-body">
          <div class="row">
            <div class="col-lg-12">
              <ul class="list-unstyled mb-0">
                <li>
                  <p> Videoaula de nivelamento <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                </li>
                <li>
                  <p> Aula expositiva <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                </li>
                <li>
                  <p> Aula experimental em horário de funcionamento da bolsa de valores <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                </li>
                <li>
                  <p>Educação continuada <i class="fa fa-check" style="color:green;" aria-hidden="true"></i></p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- Side Widget -->

    </div>

  </div>
  <!-- /.row -->
  <?php endforeach ?>

  </div>
  </div>

  <div class="card card-signin my-5" id="login"  style="position:relative;left:27%;top:-103em;width:50%;heigth:50%;display:none;border:2px solid #565da7; ">
  <div style="position:relative;background-color:#212177; width:100%;height:6em;">
      <h5 style="position:relative;top:2em;font-size:1.5rem;" class="card-title text-center"> 
      <strong style="color:white; font-family: 'Rubik', sans-serif;">ACESSE SUA CONTA</strong>
      </h5>
  </div>      
<div class="card-body">
  <a class="form-control" style="position:relative;color:black;black;width:8%;top:-5em;left:90%;"  href="#" id="fechar"><i class="fa fa-remove" style="color:blue;font-size:20px;top:-1em;left:1%;" aria-hidden="true"></i></a>
    <?php
        if ($this->session->flashdata('error')) {
        ?>
            <div class="alert alert-danger text-center" style="margin-top:20px;font-size:2rem">
                <?php echo $this->session->flashdata('error'); ?>
            </div>
            <?php
        }
    ?> 
  <form id="buttoncad" class="form-signin" style="position:relative;width:70%;top:-1em;font-size:1.2rem; left:15%;" action="/index.php/Control/logar" method="POST">
        <div class="form-label-group">
          <label for="inputEmail">Email</label>                        
          <input type="email"  id="inputEmail" style="position:relative;font-size:1.2rem;" name="email" class="form-control" placeholder="Email" required autofocus>
        </div>
        <br/>
        <div class="form-label-group">
          <label for="inputPassword">Senha</label> 
          <input type="password" id="inputPassword" style="position:relative;font-size:1.2rem;" name="senha" class="form-control" placeholder="Password" required >
        </div>
        <br/>
        <button  class="btn btn-ms btn-primary btn-block text-uppercase" style="position:relative;left:40%; background-color:white;color:blue;width:50%;font-size:1.2rem;" type="submit">Logar</button>
        <hr style="background-color:blue;" class="my-4">
        </form>
            <a href="/index.php/Control/#formindex" style="position:relative;color:blue;width:10%;left:25%;">Não possui conta? Cadastre-se</a>        </div>

    </div>
    </div>

    <script>
    document.getElementById("login").style.display = "none";
    document.getElementById("logar").addEventListener('click', function(){  
        document.getElementById("login").style.display = "block";



    });
    document.getElementById('fechar').addEventListener('click', function(evt){      
        document.getElementById("body").style["-webkit-filter"] = "brightness(100%)";

        document.getElementById("login").style.display = "none";
        
        return false;
    });
    </script>


</div>
