<?php
require_once("layout/navbar.php");

?>
    <div class="container">
    <div class="row">
    <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
      <div class="card card-signin my-5">
        <div class="card-body">
          <h5 class="card-title text-center">Alterar Conta</h5>
          <form class="form-signin" action="/index.php/Control/minhaconta" method="POST">
            <div class="form-label-group">
            <?php foreach($user as $u): ?>
                  <label for="inputPassword">Nome</label>                        
                  <input type="text" id="name" value="<? echo $u->nome ?>" name="nome" class="form-control" placeholder="Nome" required autofocus>
              </div>
              <br/>
              <div class="form-label-group">
                  <label for="inputPassword">Sobrenome</label>                        
                  <input type="text" id="name" name="sobrenome"  value="<? echo $u->sobrenome ?>" class="form-control" placeholder="Sobrenome" required>
              </div>
              <br/>
              <div class="form-label-group">
                <label for="inputEmail">Email</label>                        
                <input type="email" id="inputEmail" name="email" value="<? echo $u->email ?>" class="form-control" placeholder="Email" required >
              </div>
              <br/>
              <div class="form-label-group">
                <label for="inputPassword">Senha</label>                        
                <input type="password" id="inputPassword" name="senha" class="form-control" placeholder="Password" required>
              </div>
              <div class="form-label-group">
                <br/>
                <label for="inputPassword">Telefone</label>                        
                <input type="tel" id="inputPassword" name="tel" value="<? echo $u->numero ?>"  class="form-control" placeholder="Telefone" required>
              </div>
              <br/>
              <button class="btn btn-ms btn-primary btn-block text-uppercase" type="submit">Salvar</button>
              <hr class="my-4">
              <?  endforeach  ?>

         </form>
        </div>
      </div>
    </div>
  </div>
  </div>
  <br/>
<br/>


  <?php
  require_once("layout/footer.php");
  
  ?>