<?php
require_once("layout/navbar.php");

?>

  <!-- Page Content -->
  <div class="container">

    <!-- Page Heading/Breadcrumbs -->
    <br/>
    <h1 class="mt-4 mb-3" style="color:#244c74; text-align:center; border-bottom: 2px solid #244c74; ">
    <strong> Gx cursos e vídeos</strong>
    </h1>
    <br/>



    <!-- Blog Post -->
    <div class="row" style="box-shadow: 0 0 2em gray;background-color:white;">
    <?php foreach ($gxcursos as $row): ?> 
    <div class="col-lg-4 col-sm-6 portfolio-item"  style="position:relative; padding:3px;height:110%;">
      <br/>

        <div class="card h-100" style="position:relative;">
        <br/>
        <h4 class="card-title" style="position:relative;text-align:center;">
              <p style="color:#244c74;font-size:22px;"><? echo $row->titulo; ?></p>
              <div style="position:relative;">
              <a class="form-control" style="position:relative;color:red;width:90%;margin:4%;padding:2%;" href="deletarCurso?id=<? echo $row->id ?>"><i class="fa fa-remove" style="color:red;font-size:20px;" aria-hidden="true"></i>Deletar</a>
              <a  class="form-control" style="position:relative;color:blur;width:90%;margin:4%;padding:2%;"  style="color:blue;" href="alterarCurso?cod=<? echo $row->id ?>"> <i class="fa fa-edit" style="color:blue;font-size:18px;" aria-hidden="true"></i>Editar</a>
          </div>
        </h4>
        <h4 style="position:relative; text-align:center;color:#244c74;">Vídeos</h4>
          <div class="card-body">
          <ul>
                <?php foreach ($videos as $linha): ?> 
                <?if($linha->id_curso == $row->id ) { ?>
                <li><a href="http://"><?  echo $linha->titulo; ?></a>            
                <a href="excluirVideo?id=<? echo $linha->id ?>"  style="color:red;"><i class="fa fa-remove" style="color:red;font-size:20px;" aria-hidden="true"></i>Deletar</a>
                <a href="alterarVideo?id=<? echo $linha->id ?>"  style="color:blue;"><i class="fa fa-edit" style="color:blue;font-size:18px;" aria-hidden="true"></i>Editar</a>
                </li>
                <? } ?>
                <?php endforeach ?>
                </ul>
          </div>
          </div>
        </div>
    <?php endforeach ?>
    </div>  


  </div>
  </div>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
  <!-- /.container -->
  <?php
  require_once("layout/footer.php");
  
  ?>